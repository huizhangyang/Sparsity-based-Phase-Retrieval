If you use this code, please cite the following reference. 
%%%%%% Baoshun Shi, Qiusheng Lian, Shuzhen Chen, Xiaoyu Fan
%%%%%%��SBM3D: Sparse regularization model induced by BM3D for weighted diffraction imaging problem, submitted to IEEE Access.
We suggest that all the tests are performed on the Windows 10 64 bit operator system and MATLAB 2017a.
You can run the file  Demo.m to simulate the recovery of the real-valued images from the coded diffraction pattern. 
