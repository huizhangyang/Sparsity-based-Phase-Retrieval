function Demo() 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Coded diffraction imaging for real-valued images
%%%%%%%%%%%%%%last modified by shibaoshun 2018 May 10th
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  clc 
  clear all
  close all
% ================ add path=================== ============================ 
  CurrPath = cd;
  addpath(genpath(CurrPath));
% ========== initialization: test setup / data ============================
  rng('default') 
  Imagenumber=1;% select an image
  switch Imagenumber
  case 1
   ori_image='Lena512.png';
  case 2
   ori_image='barbara.png';
  case 3
   ori_image='hill.png';
  case 4
   ori_image='boat.png';
  case 5
   ori_image='couple.png';
  case 6
   ori_image='fingerprint.png';
  case 7
   ori_image='man.png';
  case 8
   ori_image='mandril512.png';  
  end
  Imin=double(imread(ori_image))/255;
%% Make masks and linear sampling operators
  type ='cdp'; % sampling using the CDP model
% create (phase retrieval) instance: (see instanceGeneration.m for details)
  data.cdptype       ='quatary';
  gamma=0;% 0 for gaussian noise
  outliers=0;
  data.numM=0.5;% sample ratio
  savefile=[];
  SNRnumber=[5 10 15 20 25];% noise level
  maxiter=size(SNRnumber,2);
for j=1:1:maxiter
  SNR =SNRnumber(j);% level of noise (added to measurements)
  [Y,F,M,S,wvar] = instanceGenerator(Imin,type,data,savefile,SNR,gamma,outliers);  % obtain the noisy measurements
%% define the sampling operator  
  phi = @(I) F(I,0); 
  phit = @(I) F(I,1)*numel(I);  
%% innitial guess
%  x=rand(size(Imin));  
  load initialguess.mat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%PR_Reweighted_SBM3D_AGD%%%%%%%%%%%%%%%%%%
  Iout=PR_Reweighted_SBM3D_AGD(Y,phi,phit,x);% 2018/5/10   
%% show result
  P(j)=PSNR(Iout,Imin)
  [FSIM(j), ~] = FeatureSIM(Imin,Iout);
  fprintf('PSNR = %.2f\n',P(j));
  fprintf('FSIM = %.4f\n',FSIM(j));
  figure (1)
  imshow(Imin,[])
  title('Original image')
  figure (2)
  imshow(Iout,[])
  title('Recovered image')
  save data
end

