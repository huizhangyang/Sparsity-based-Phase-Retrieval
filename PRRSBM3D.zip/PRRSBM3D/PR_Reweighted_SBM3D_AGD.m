function [x,P]=PR_Reweighted_SBM3D_AGD(Y,phi,phit,x)
%% This algorithm exploits the SBM3D model and the reweighted technique.
%% If you use this code, please cite the following reference. 
%%%%%% Baoshun Shi, Qiusheng Lian, Shuzhen Chen, Xiaoyu Fan
%%%%%%��SBM3D: Sparse regularization model induced by BM3D for weighted diffraction imaging problem, submitted to IEEE Access.
%% parameters
    lamuda=0.12*numel(Y);
    gammaX=5e-6;
    maxiteration=70; 
    mu=0.09;
    objval = @(YYhat,X,Xdenoise,Weight)0.25*sum(abs(Weight(:).*(YYhat(:)-Y(:))).^2)... %% define the cost function
     +lamuda*sum(sum(abs(X-Xdenoise))); 
%% innitial guess   
    tk=0;
    xold = x; 
    xoold= xold;
    tk_old=tk;
for i=1:1:maxiteration
%% BM3D denoise
    Nsig=1.6*mad(x); 
    [~,Idenoise] = BM3D(x,x,Nsig*255, 'lc',0);     
%% AGD
    tk=(1+sqrt(1+4*tk_old^2))/2;
    z=xold+(tk_old-1)*(xold-xoold)/tk;        
%% update x by using AGD with an adaptive step size
    if i==1
    Yhat  = abs(phi(x)).^2;     
    Weight1=1./(1+(abs(Yhat-Y))); 
    obj=objval(Yhat,x,Idenoise,Weight1);
    end
    Yhat  = abs(phi(z)).^2;
    temp=z-Idenoise;
    temp=temp-soft(temp,mu);
    gradhx=(lamuda/mu)*temp;
    Weight1=1./(1+(abs(Yhat-Y)));
    gradgx=real(phit(Weight1.*phi(z).*(Yhat-Y))); 
    gradX=gradhx+gradgx;
    oldobj = obj; count = 1;  
    while(true)                          %line search
          x=z-gammaX*gradX;%
          Yhat  = abs(phi(x)).^2;
          Weight1=1./(1+(abs(Yhat-Y)));
          obj = objval(Yhat,x,Idenoise,Weight1);
          if( oldobj >= obj ), break; end % successfully decreased objective
            gammaX = gammaX*0.88;
            count = count+1;
         if( count >= 100 ), break; end  % linesearch failed (100 trials)
    end
    gammaX = 1.68*gammaX;
    Residual= norm(x-xold)/norm(x);
    if  Residual<1e-4
    break;
    end
    xoold=xold;
    xold = x;  
    fprintf('Iteration= %d\n',i);
end
