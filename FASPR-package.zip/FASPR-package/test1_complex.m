function test1_complex()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Coded diffraction imaging for complex-valued images at Gaussion noise SNR=20dB case
%% This function considers the comparson of the SPAR algorithm and the FASPR algorithm at various sampling ratios.
%%%%%%%%%%%%%%last modified by shibaoshun 2018 Jan 18th
%% add path
clear ;
close all;
CurrPath = cd;
addpath(genpath(CurrPath));
%% 
rng('default');    
Result=cell(10,25);% 11*3(5 images 2 algorihtms) 5*5(5 cdo number 5 evalation metric)
% load dataComplexSNR50.mat
type ='cdp'; 
data.cdptype       ='quatary';            %'complex'; %'quatary'; %'ternary';%  type of cdp masks {'binary';'ternary';'complex'};% binary 1 or -1
SNR                =50;                   % level of noise (added to measurements)
gamma=0;% 0 for gaussian noise  In our paper we only consider the Gaussion noise case 
outliers=0;
savefile           =   []; % filename to save instance data%% select an image
for i=1:1:5
%% generate complex-valued images    
Imagenumber=i;
 switch Imagenumber
 case 1  
   Magintude ='Cameraman256.png';
   Phase ='peppers256.png';
 case 2 
   Magintude ='montage256.png';
   Phase ='house256.png';   
 case 3 
   Magintude ='Lena512.png';
   Phase ='hill.png';   
 case 4 
   Magintude ='barbara.png';
   Phase ='boat.png';   
 case 5 
   Magintude ='couple.png';
   Phase ='fingerprint.png';     
 end
im_real =im2double(imread(Magintude))*0.9+0.1;
phase_temp =im2double(imread(Phase));
phase_real =(phase_temp)*pi; % 0~pi
Xopt= im_real .* (cos(phase_real) + 1j*sin(phase_real));% generate complex object
iter=40;
SamplingRatio=[0.2 0.4 0.6 0.8];
L=1;                 % define the cdp number
maxiter=size(SamplingRatio,2);
%% innitial guess
% X0 = rand(size(Xopt));
% X0=X0.*(cos(X0*pi) + 1j*sin(X0*pi));
%load initialguess.mat
if size(Xopt,2)==256              %% use the same random initial guess
    load X0256Complex.mat       
else
    load X0512Complex.mat
end
for j=1:1:maxiter
P=SamplingRatio(j);    % select a sampling ratio P/2
data.numM=P;                                                  % sample ratio
[Y,F,M,S,noisePower] = instanceGenerator(Xopt,type,data,savefile,SNR,gamma,outliers);
%% %%%%%%%%%%%%%%%%%%%%%<<<<Our proposed FASPR algorithm>>>%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function FASPR.....\n');
t=clock;
[Image,P1,P2] = FASPR_Complex(F,Y,iter,X0,Xopt,noisePower);
time=etime(clock,t);
%% compute PSNR and FSIM
PSNR1= psnr(abs(Xopt), abs(Image));
PSNR2= psnr(angle(Xopt)/pi,angle(Image)/pi );
[FSIM1, ~] = FeatureSIM(abs(Xopt), abs(Image));
[FSIM2, ~] = FeatureSIM(angle(Xopt)/pi,angle(Image)/pi );
fprintf('The recovered magnitude image PSNR = %.2f\n',PSNR1);
fprintf('The recovered phase image PSNR = %.2f\n',PSNR2);  
fprintf('The recovered magnitude image FSIM = %.2f\n',FSIM1);
fprintf('The recovered phase image FSIM = %.2f\n',FSIM2);   
save test1complex
end
end
