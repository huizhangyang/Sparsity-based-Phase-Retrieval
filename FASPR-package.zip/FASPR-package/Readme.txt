If you use this code, please cite the following reference. 
Baoshun Shi, Shuzhen Chen, Ye Tian, Xiaoyu Fan, Qiusheng Lian, ��FASPR: A Fast Sparse Phase Retrieval Algorithm via the Epigraph Concept��, submitted to Digital Signal Processing. 
We suggest that all the tests are performed on the Windows 10 64 bit operator system and MATLAB 2017a.
You can run the file test1_real.m to simulate the recovery of the real-valued images from undersampled coded diffraction pattern. 
You can run the file test1_complex.m to simulate the recovery of the complex-valued images from undersampled coded diffraction pattern. 