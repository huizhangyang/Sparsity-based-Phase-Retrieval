function Rn=Rnoise(Fabs,Fabs_n) % define as OSS, lqs, 2014,11.28
Rn=sum(sum(abs(Fabs-Fabs_n)))/sum(sum(Fabs));