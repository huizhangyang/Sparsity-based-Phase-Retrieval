function y=proj_tv_cplx(x0,iters,lamda)% lqs 2016.10.21
cost0=inf;cost1=cost0;
xn=x0;
if ~exist('iters','var')
    iters=1;
end
x=x0;
if ~exist('lamda','var' )
   lamda=1;
end
for i=1:iters 
   magx=abs(x);
   magx(magx==0)=eps;
   angx=angle(x);
   grad_tv=lamda*x.*gradvar(magx)./magx+1j*x.*(gradvar(angx))./magx.^2; 
   tv=lamda*total_variation(magx)+total_variation(angx);
   x=x-tv*grad_tv/(1+sum(abs(grad_tv(:)).^2));  
   cost0=cost1;
   cost1=sum(abs(xn(:) - x(:)).^2);
   if cost1>=cost0
       x=(x+x0)/2;  
       cost1=sum(abs(xn(:) - x(:)).^2);
   end  
   %x=PS_Cplx(x,1);
   x0=x;  
end
y=x;

