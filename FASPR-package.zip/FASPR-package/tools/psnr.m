function z=psnr(x,y)
   rmse    =  @(x,y)sqrt( sum( (y(:)-x(:)).^2) / numel(y) );
   z    =  10*log10 ( 1 / rmse(im2double(x),im2double(y))^2);
end