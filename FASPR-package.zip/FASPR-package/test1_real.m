 function test1_real()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Coded diffraction imaging for real-valued images at 50 db
%%%%%%%%%%%%%%last modified by shibaoshun 2018 Jan 31th
%% add path
clear ;
close all;
CurrPath = cd;
addpath(genpath(CurrPath));
%% 
rng('default');    
Result=cell(40,20);% 10*4(10 images 4 algorihtms) 4*5(5 sampling ratios 5 evalation metric)
type ='cdp'; 
data.cdptype       ='quatary';            %'complex'; %'quatary'; %'ternary';%  type of cdp masks {'binary';'ternary';'complex'};% binary 1 or -1
noiseless          =0;                    % 1 stands for a noiseless case 
SNR                =50;                   % level of noise (added to measurements)
gamma=0;% 0 for gaussian noise  In our paper we only consider the Gaussion noise case 
outliers=0;
savefile           =   []; % filename to save instance data%% select an image
for i=1:1:10
Imagenumber=i;
 switch Imagenumber
 case 1
 ori_image='Cameraman256.png';
 case 2
 ori_image='peppers256.png';
 case 3
 ori_image='montage256.png';
 case 4
 ori_image='house256.png';
 case 5
 ori_image='Lena512.png';
 case 6
 ori_image='barbara.png';
 case 7
 ori_image='hill.png';
 case 8
 ori_image='boat.png';
 case 9
 ori_image='couple.png';
 case 10
 ori_image='fingerprint.png';
 end
rng('default');
disp(['Loading image ',ori_image]);
disp(' ');
Xopt=double(imread(ori_image))/255;
iter=30;
SamplingRatio=[0.2 0.4 0.6 0.8];
maxiter=size(SamplingRatio,2);
%% innitial guess
% X0 = rand(size(Xopt));
%load initialguess.mat
if size(Xopt,2)==256              %% use the same random initial guess, the fixed initial guess just for produsing our results
    load X0256.mat       
else
    load X0512.mat
end
for j=1:1:maxiter
P=SamplingRatio(j);    % select a sampling ratio
data.numM=P;                                                  % sample ratio
[Y,F,M,S,noisePower] = instanceGenerator(Xopt,type,data,savefile,SNR,gamma,outliers);
%% %%%%%%%%%%%%%%%%%%%%%<<<<Our proposed FASPR algorithm>>>%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('calling the function FASPR.....\n');
t=clock;
[Image,P] = FASPR_Real(F,Y,iter,X0,Xopt,noisePower);
time=etime(clock,t);
PSNR=psnr(Image,Xopt);
[FSIM, ~] = FeatureSIM(Xopt, Image);
fprintf(1,'psnr = %f \n', PSNR);
fprintf(1,'FSIM = %f \n', FSIM);
save test1real
end
end
