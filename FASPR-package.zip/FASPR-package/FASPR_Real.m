function [X,P] = FASPR_Real(F,Y,iter,X0,Xopt,sigma)
%% This algorithm exploits the sparisity in gradient domain via the epigraph concept.
%%%% Only the iteartion times need to be specified.
%% If you use this code, please cite the following reference. 
%%%%%% Baoshun Shi, Shuzhen Chen, Ye Tian, Xiaoyu Fan, Qiusheng Lian, 
%%%%%%��FASPR: A Fast Sparse Phase Retrieval Algorithm via the Epigraph Concept��, submitted to Digital Signal Processing.
   Y=Y.*(Y>0);
   Y=sqrt(Y);
%% initialization  
   rk=X0;
   tk=1;
   X = X0;
   Xoold=X0;
   if sigma<=60        %% set the iterations. 
     J=1;
   else
     J=1+3*ceil((sigma-60)/5);
   end
% %%%%%%%%%% main loop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii=1:iter    
%% phase recover step   
    yk=F(rk,0);
   Ycplx=Y.*sign(yk);
   grad=F(yk-Ycplx,1);
%% compute the optimal step-size via Eq. (16)
   h=F(grad,0);
   r=yk-Ycplx;
   u=real(conj(r).*h);% 
   eta1=sum(u(:))/sum(abs(h(:)).^2);
   if eta1>0
      eta=eta1;
   end
   eta=max(eps,min(eta,1));
   X_old=X;
%% projection onto the epigraph set of the TV funtion   
   yk=F(rk,0);
   Ycplx=Y.*sign(yk);
   grad=real(F(yk-Ycplx,1));
   X=rk - eta*grad;
   X= proj_tv(X,J);
   tk_old=tk;
   tk=(1+sqrt(1+4*tk^2))/2;      %% FISTA  Eq. (10)
   rk=X+(tk_old-1)*(X-X_old)/tk; %%        Eq. (11)
  %% show result
    P(ii)=psnr(X,Xopt);
    fprintf('PSNR = %.2f\n',P(ii));
    Residual= norm(X-Xoold)/norm(X);
    if  Residual<1e-4
    break;
    end
    Xoold=X;
end
