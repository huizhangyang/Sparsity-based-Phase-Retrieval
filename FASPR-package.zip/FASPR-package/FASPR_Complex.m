function [Iout,P1,P2] = FASPR_Complex(F,Y,iter,X0,Xopt,sigma) 
%% This algorithm exploits the sparisity of complex-valued images in gradient domain via the epigraph concept.
%%%% Only the iteartion times need to be specified.
%% If you use this code, please cite the following reference. 
%%%%%% Baoshun Shi, Shuzhen Chen, Ye Tian, Xiaoyu Fan, Qiusheng Lian, 
%%%%%%��FASPR: A Fast Sparse Phase Retrieval Algorithm via the Epigraph Concept��, submitted to Digital Signal Processing.
   Y=Y.*(Y>0);
   Y=sqrt(Y);
%% initialization  
   rk=X0;
   tk=1;
   X = X0;
   if sigma<=70              %% set the iterations. 
    J=5;
   else
    J=5+10*ceil((sigma-70)/5);
   end
% %%%%%%%%%% main loop %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii=1:iter    
%% phase recover step  
   yk=F(rk,0);
   Ycplx=Y.*sign(yk);
   grad=F(yk-Ycplx,1);
   h=F(grad,0);
%% compute the optimal step-size  
   r=yk-Ycplx;
   u=real(conj(r).*h);% 
   eta1=sum(u(:))/sum(abs(h(:)).^2);
   if eta1>0
      eta=eta1;
   end
   eta=max(eps,min(eta,1));
   X_old=X;
%% projection onto the epigraph set of the TV funtion   
   X=rk - eta*grad;
   X=proj_tv_cplx(X,J,pi);% Note the parameter lamuda=pi!
   tk_old=tk;                 
   tk=(1+sqrt(1+4*tk^2))/2;     %% FISTA  Eq. (10)
   rk=X+(tk_old-1)*(X-X_old)/tk;%%        Eq. (11)
   Iout=exp(-1i*(angle(trace(Xopt'*X)))) * X;  %% Phase correction by an invariant shift according to x
   P1(ii)= psnr(abs(Xopt),abs(Iout));
   P2(ii)= psnr(angle(Xopt)/pi,angle(Iout)/pi);
   fprintf('The recovered magnitude image PSNR = %.2f\n',P1(ii));
   fprintf('The recovered phase image PSNR = %.2f\n',P2(ii));    
end
return;

