If you use this code, please cite the following reference. 
BAOSHUN SHI, QIUSHENG LIAN, XIN HUANG, AND NI AN, ��Constrained Phase Retrieval: when alternating projection meets regularization��, submitted to JOSA B. 
We suggest that all the tests are performed on the Windows 10 64 bit operator system and MATLAB 2017a.
You can run the file  Demo_ConPR.m to simulate the recovery of the real-valued images from one coded diffraction pattern. 
